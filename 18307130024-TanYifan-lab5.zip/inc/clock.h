#ifndef INC_CLOCK_H
#define INC_CLOCK_H

void clock_init();
void clock_reset();
void clock();

#endif
